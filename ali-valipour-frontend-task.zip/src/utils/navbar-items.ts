export const MOCK_NAVBAR_ITEMS = [
  "پخش زنده",
  "فیلم و سریال",
  "کودک",
  "ورزش",
  "آرشیو محتوایی",
];
